package expr;

public interface Expression {
    double value(double x);
}
