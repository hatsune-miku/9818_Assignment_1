package expressionTree.parser;

public class ParseException extends Exception {

}
